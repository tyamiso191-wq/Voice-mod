# SimpleVoiceChatAEC

Client-side **Acoustic Echo Cancellation (AEC)** bridge for **Simple Voice Chat 2.6.16** on **Minecraft 1.21.11 (Fabric)**, aimed at **Android / MojoLauncher** (e.g. Redmi 12C) when using the speaker without headphones.

Simple Voice Chat is **not** replaced or patched beyond a single client-side Mixin. The mod sits next to SVC and only swaps the microphone capture path when Android media APIs are present.

## Problem

Without headphones, the far-end voice played through the speaker is picked up by the microphone and sent back → echo / feedback.

## Approach (real SVC APIs)

Inspected Simple Voice Chat `1.21.11` branch source:

| Component | Class / method |
|-----------|----------------|
| Mic interface | `de.maxhenkel.voicechat.voice.client.microphone.Microphone` (`open/start/stop/close/available/read`) |
| OpenAL capture | `ALMicrophone` (`ALC_EXT_CAPTURE`) |
| Java Sound | `JavaxMicrophone` |
| Factory | `MicrophoneManager.createMicrophone()` |
| Consumer | `MicThread` → `mic.read()` → `short[]` @ 48 kHz, frame 960 samples |

**Injection point:** Mixin on `MicrophoneManager.createMicrophone()` (HEAD, cancellable).

**Android path:**

1. Detect Android (`android.os.Build` / system properties).
2. Open `AudioRecord` with `MediaRecorder.AudioSource.VOICE_COMMUNICATION` (value `7`), 48 kHz mono PCM 16-bit.
3. If `AcousticEchoCanceler.isAvailable()` → `AcousticEchoCanceler.create(sessionId)` + `setEnabled(true)`.
4. Feed clean PCM into SVC’s existing encoder / network path via the `Microphone` interface.
5. On any failure → **do not cancel** the Mixin; SVC continues with AL / Javax as usual.

All Android types are accessed **only via reflection** so the mod loads on desktop JVMs.

## Requirements

- Minecraft **1.21.11**
- Fabric Loader + Fabric API
- **Simple Voice Chat 2.6.16** (Fabric jar for 1.21.11)
- Android 8+ recommended; target tested intent: **Redmi 12C** / MojoLauncher
- RECORD_AUDIO permission granted to the launcher

Optional companion: [Android Audio Shim](https://modrinth.com/mod/android-audio-shim) (AAudio/OpenSL) — this mod targets system AEC via `VOICE_COMMUNICATION`, not a replacement for the shim’s speaker path.

## Build

```bash
./gradlew build
```

Output:

```text
build/libs/SimpleVoiceChatAEC-1.0.0.jar
```

Place the jar in the instance `mods` folder together with Simple Voice Chat.

## Behaviour summary

| Environment | Behaviour |
|-------------|-----------|
| Desktop | Mixin no-ops; normal SVC microphone |
| Android + AEC available | `AudioRecord(VOICE_COMMUNICATION)` + `AcousticEchoCanceler` |
| Android + AEC unavailable | Still tries `VOICE_COMMUNICATION` (many devices still apply hardware AEC/NS); else fallback |
| Open / start failure | Logged; SVC default mic used |

## Limitations (honest)

1. **True AEC** works best when capture and playback share the same Android audio session / stream type. SVC plays through OpenAL / launcher audio (often OpenSL/AAudio). Hardware AEC quality therefore depends on the OEM and launcher routing. `VOICE_COMMUNICATION` is still the correct source for “voice call” style processing on Android.
2. `AudioRecord.available()`-style semantics differ from OpenAL; the implementation reports frames optimistically and zero-pads short reads so `MicThread` stays compatible.
3. If the launcher JVM does not expose `android.media.*` to game code, the mod safely falls back.
4. This mod does **not** implement software AEC (e.g. WebRTC AEC3) in pure Java; that would need a native library and a reference signal from the speaker path.

## Logs

Look for:

```text
[simplevoicechataec] SimpleVoiceChatAEC loaded. Android=..., AcousticEchoCanceler.isAvailable()=...
[simplevoicechataec] Using Android AEC microphone (VOICE_COMMUNICATION)
```

or fallback warnings.

## License

MIT
