package com.simplevoicechataec.mixin;

import com.simplevoicechataec.SimpleVoiceChatAECClient;
import com.simplevoicechataec.microphone.AndroidAECMicrophone;
import com.simplevoicechataec.microphone.AndroidAECSupport;
import de.maxhenkel.voicechat.voice.client.MicrophoneException;
import de.maxhenkel.voicechat.voice.client.microphone.Microphone;
import de.maxhenkel.voicechat.voice.client.microphone.MicrophoneManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Intercepts Simple Voice Chat's microphone factory.
 * On Android, tries to open AudioRecord(VOICE_COMMUNICATION) + AcousticEchoCanceler.
 * On failure or non-Android, leaves the original return value (AL / Javax mic).
 * <p>
 * Target verified against Simple Voice Chat 2.6.16 (1.21.11 branch):
 * de.maxhenkel.voicechat.voice.client.microphone.MicrophoneManager#createMicrophone()
 */
@Mixin(value = MicrophoneManager.class, remap = false)
public class MicrophoneManagerMixin {

    @Inject(method = "createMicrophone", at = @At("HEAD"), cancellable = true, remap = false)
    private static void simplevoicechataec$tryAndroidAec(CallbackInfoReturnable<Microphone> cir) {
        if (!AndroidAECSupport.isAndroid()) {
            return;
        }

        try {
            AndroidAECMicrophone aecMic = new AndroidAECMicrophone();
            aecMic.open();
            SimpleVoiceChatAECClient.LOGGER.info("Using Android AEC microphone (VOICE_COMMUNICATION)");
            cir.setReturnValue(aecMic);
        } catch (MicrophoneException e) {
            SimpleVoiceChatAECClient.LOGGER.warn(
                    "Android AEC microphone failed, falling back to Simple Voice Chat default: {}",
                    e.getMessage());
            // Do not cancel — original createMicrophone continues
        } catch (Throwable t) {
            SimpleVoiceChatAECClient.LOGGER.warn(
                    "Unexpected error creating Android AEC microphone, falling back: {}",
                    t.toString());
        }
    }
}
