package com.simplevoicechataec;

import com.simplevoicechataec.microphone.AndroidAECSupport;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client-only entrypoint.
 * Does not modify Simple Voice Chat; only injects an alternative Microphone
 * implementation on Android when AcousticEchoCanceler / VOICE_COMMUNICATION is available.
 */
public class SimpleVoiceChatAECClient implements ClientModInitializer {

    public static final String MOD_ID = "simplevoicechataec";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        boolean android = AndroidAECSupport.isAndroid();
        boolean aecAvailable = AndroidAECSupport.isAcousticEchoCancelerAvailable();
        LOGGER.info("SimpleVoiceChatAEC loaded. Android={}, AcousticEchoCanceler.isAvailable()={}",
                android, aecAvailable);
        if (android) {
            if (aecAvailable) {
                LOGGER.info("Will prefer AudioRecord(VOICE_COMMUNICATION) + AcousticEchoCanceler for microphone capture.");
            } else {
                LOGGER.info("AcousticEchoCanceler not reported available; will still try VOICE_COMMUNICATION source if AudioRecord works, else fall back to Simple Voice Chat default mic.");
            }
        } else {
            LOGGER.info("Not running on Android — AEC bridge inactive, Simple Voice Chat uses its normal microphone.");
        }
    }
}
