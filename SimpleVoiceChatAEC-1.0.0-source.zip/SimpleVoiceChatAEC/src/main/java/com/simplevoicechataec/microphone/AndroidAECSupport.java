package com.simplevoicechataec.microphone;

import com.simplevoicechataec.SimpleVoiceChatAECClient;

import java.lang.reflect.Method;

/**
 * Reflection helpers for Android media APIs.
 * On desktop / non-Android JVMs all checks return false and no Android classes are loaded.
 */
public final class AndroidAECSupport {

    private static final Boolean ANDROID;
    private static final Boolean AEC_AVAILABLE;

    static {
        ANDROID = detectAndroid();
        AEC_AVAILABLE = ANDROID && detectAecAvailable();
    }

    private AndroidAECSupport() {
    }

    public static boolean isAndroid() {
        return ANDROID;
    }

    /**
     * Calls android.media.audiofx.AcousticEchoCanceler.isAvailable() via reflection.
     */
    public static boolean isAcousticEchoCancelerAvailable() {
        return AEC_AVAILABLE;
    }

    private static boolean detectAndroid() {
        // Common markers used by Pojav / Mojo / Android OpenJDK ports
        String vendor = System.getProperty("java.vendor", "");
        String runtime = System.getProperty("java.runtime.name", "");
        String vm = System.getProperty("java.vm.name", "");
        String os = System.getProperty("os.name", "");
        if (os.toLowerCase().contains("android")
                || vendor.toLowerCase().contains("android")
                || runtime.toLowerCase().contains("android")
                || vm.toLowerCase().contains("dalvik")
                || vm.toLowerCase().contains("art")) {
            return true;
        }
        try {
            Class.forName("android.os.Build");
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean detectAecAvailable() {
        try {
            Class<?> aecClass = Class.forName("android.media.audiofx.AcousticEchoCanceler");
            Method isAvailable = aecClass.getMethod("isAvailable");
            Object result = isAvailable.invoke(null);
            return result instanceof Boolean && (Boolean) result;
        } catch (Throwable t) {
            SimpleVoiceChatAECClient.LOGGER.debug("AcousticEchoCanceler.isAvailable() check failed: {}", t.toString());
            return false;
        }
    }
}
