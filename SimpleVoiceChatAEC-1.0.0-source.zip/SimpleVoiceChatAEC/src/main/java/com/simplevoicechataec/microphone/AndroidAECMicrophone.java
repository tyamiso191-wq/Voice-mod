package com.simplevoicechataec.microphone;

import com.simplevoicechataec.SimpleVoiceChatAECClient;
import de.maxhenkel.voicechat.voice.client.MicrophoneException;
import de.maxhenkel.voicechat.voice.client.microphone.Microphone;
import de.maxhenkel.voicechat.voice.common.AudioUtils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Microphone implementation that uses Android AudioRecord with
 * MediaRecorder.AudioSource.VOICE_COMMUNICATION and optionally
 * AcousticEchoCanceler attached to the audio session.
 * <p>
 * All Android types are accessed via reflection so this class loads on desktop JVMs.
 * If anything fails, the caller must fall back to the normal Simple Voice Chat mic.
 */
public class AndroidAECMicrophone implements Microphone {

    // Matches Simple Voice Chat
    private static final int SAMPLE_RATE = AudioUtils.SAMPLE_RATE; // 48000
    private static final int FRAME_SIZE = AudioUtils.FRAME_SIZE;   // 960
    private static final int CHANNEL_IN_MONO = 16;                 // AudioFormat.CHANNEL_IN_MONO
    private static final int ENCODING_PCM_16BIT = 2;               // AudioFormat.ENCODING_PCM_16BIT
    private static final int VOICE_COMMUNICATION = 7;              // MediaRecorder.AudioSource.VOICE_COMMUNICATION
    private static final int STATE_INITIALIZED = 1;
    private static final int RECORDSTATE_RECORDING = 3;

    private Object audioRecord;          // android.media.AudioRecord
    private Object acousticEchoCanceler; // android.media.audiofx.AcousticEchoCanceler (optional)
    private boolean started;
    private final byte[] readBuffer = new byte[FRAME_SIZE * 2];
    private final short[] shortBuffer = new short[FRAME_SIZE];

    // Cached reflection
    private Method arStartRecording;
    private Method arStop;
    private Method arRelease;
    private Method arGetRecordingState;
    private Method arReadShorts; // prefer short[] read if present
    private Method arReadBytes;
    private Method arGetState;
    private Method aecSetEnabled;
    private Method aecRelease;

    public AndroidAECMicrophone() {
    }

    @Override
    public void open() throws MicrophoneException {
        if (isOpen()) {
            throw new MicrophoneException("Android AEC microphone already open");
        }
        try {
            openInternal();
        } catch (MicrophoneException e) {
            throw e;
        } catch (Throwable t) {
            closeQuietly();
            throw new MicrophoneException("Failed to open Android AudioRecord AEC microphone: " + t.getMessage());
        }
    }

    private void openInternal() throws Exception {
        Class<?> audioRecordClass = Class.forName("android.media.AudioRecord");
        Class<?> audioFormatClass = Class.forName("android.media.AudioFormat");

        Method getMinBufferSize = audioRecordClass.getMethod(
                "getMinBufferSize", int.class, int.class, int.class);
        int minBuf = (Integer) getMinBufferSize.invoke(null, SAMPLE_RATE, CHANNEL_IN_MONO, ENCODING_PCM_16BIT);
        if (minBuf <= 0) {
            throw new MicrophoneException("AudioRecord.getMinBufferSize returned " + minBuf);
        }
        // Larger buffer for stability under load (common pattern in WebRTC / voice apps)
        int bufferSizeInBytes = Math.max(minBuf * 2, FRAME_SIZE * 2 * 4);

        Constructor<?> ctor = audioRecordClass.getConstructor(
                int.class, int.class, int.class, int.class, int.class);
        audioRecord = ctor.newInstance(
                VOICE_COMMUNICATION,
                SAMPLE_RATE,
                CHANNEL_IN_MONO,
                ENCODING_PCM_16BIT,
                bufferSizeInBytes
        );

        arGetState = audioRecordClass.getMethod("getState");
        int state = (Integer) arGetState.invoke(audioRecord);
        if (state != STATE_INITIALIZED) {
            releaseAudioRecord();
            throw new MicrophoneException("AudioRecord not initialized (state=" + state + ")");
        }

        arStartRecording = audioRecordClass.getMethod("startRecording");
        arStop = audioRecordClass.getMethod("stop");
        arRelease = audioRecordClass.getMethod("release");
        arGetRecordingState = audioRecordClass.getMethod("getRecordingState");

        // Prefer read(short[], int, int)
        try {
            arReadShorts = audioRecordClass.getMethod("read", short[].class, int.class, int.class);
        } catch (NoSuchMethodException e) {
            arReadShorts = null;
        }
        arReadBytes = audioRecordClass.getMethod("read", byte[].class, int.class, int.class);

        // Attach AcousticEchoCanceler if available
        tryAttachAec(audioRecordClass);

        SimpleVoiceChatAECClient.LOGGER.info(
                "Android AEC microphone opened (VOICE_COMMUNICATION, sampleRate={}, bufferBytes={}, aec={})",
                SAMPLE_RATE, bufferSizeInBytes, acousticEchoCanceler != null);
    }

    private void tryAttachAec(Class<?> audioRecordClass) {
        if (!AndroidAECSupport.isAcousticEchoCancelerAvailable()) {
            return;
        }
        try {
            Method getAudioSessionId = audioRecordClass.getMethod("getAudioSessionId");
            int sessionId = (Integer) getAudioSessionId.invoke(audioRecord);

            Class<?> aecClass = Class.forName("android.media.audiofx.AcousticEchoCanceler");
            Method create = aecClass.getMethod("create", int.class);
            Object aec = create.invoke(null, sessionId);
            if (aec == null) {
                SimpleVoiceChatAECClient.LOGGER.warn("AcousticEchoCanceler.create({}) returned null", sessionId);
                return;
            }
            aecSetEnabled = aecClass.getMethod("setEnabled", boolean.class);
            aecRelease = aecClass.getMethod("release");
            aecSetEnabled.invoke(aec, true);
            acousticEchoCanceler = aec;
            SimpleVoiceChatAECClient.LOGGER.info("AcousticEchoCanceler enabled on session {}", sessionId);
        } catch (Throwable t) {
            SimpleVoiceChatAECClient.LOGGER.warn("Could not attach AcousticEchoCanceler: {}", t.toString());
            acousticEchoCanceler = null;
        }
    }

    @Override
    public void start() {
        if (!isOpen() || started) {
            return;
        }
        try {
            arStartRecording.invoke(audioRecord);
            started = true;
        } catch (Throwable t) {
            SimpleVoiceChatAECClient.LOGGER.error("AudioRecord.startRecording failed", t);
        }
    }

    @Override
    public void stop() {
        if (!isOpen() || !started) {
            return;
        }
        try {
            arStop.invoke(audioRecord);
        } catch (Throwable t) {
            SimpleVoiceChatAECClient.LOGGER.debug("AudioRecord.stop: {}", t.toString());
        }
        started = false;
        // Drain residual samples so the next start is clean
        try {
            while (availableInternal() >= FRAME_SIZE) {
                readInternal();
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void close() {
        stop();
        closeQuietly();
    }

    private void closeQuietly() {
        if (acousticEchoCanceler != null) {
            try {
                if (aecSetEnabled != null) {
                    aecSetEnabled.invoke(acousticEchoCanceler, false);
                }
                if (aecRelease != null) {
                    aecRelease.invoke(acousticEchoCanceler);
                }
            } catch (Throwable ignored) {
            }
            acousticEchoCanceler = null;
        }
        releaseAudioRecord();
        started = false;
    }

    private void releaseAudioRecord() {
        if (audioRecord != null) {
            try {
                if (arRelease != null) {
                    arRelease.invoke(audioRecord);
                }
            } catch (Throwable ignored) {
            }
            audioRecord = null;
        }
    }

    @Override
    public boolean isOpen() {
        if (audioRecord == null || arGetState == null) {
            return false;
        }
        try {
            return (Integer) arGetState.invoke(audioRecord) == STATE_INITIALIZED;
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public boolean isStarted() {
        if (!isOpen() || arGetRecordingState == null) {
            return false;
        }
        try {
            return (Integer) arGetRecordingState.invoke(audioRecord) == RECORDSTATE_RECORDING;
        } catch (Throwable t) {
            return started;
        }
    }

    @Override
    public int available() {
        return availableInternal();
    }

    /**
     * AudioRecord does not expose a reliable "available samples" count like ALC.
     * We approximate by always claiming enough when recording, and relying on
     * MicThread's poll loop + non-blocking read behaviour.
     * Returning FRAME_SIZE when recording keeps MicThread moving; actual read
     * may return fewer samples which we zero-pad if needed.
     */
    private int availableInternal() {
        if (!isStarted()) {
            return 0;
        }
        // Optimistic: report at least one frame so MicThread calls read().
        // Real timing is driven by AudioRecord blocking/non-blocking read.
        return FRAME_SIZE;
    }

    @Override
    public short[] read() {
        if (!isOpen()) {
            throw new IllegalStateException("Android AEC microphone was not opened");
        }
        return readInternal();
    }

    private short[] readInternal() {
        try {
            if (arReadShorts != null) {
                int n = (Integer) arReadShorts.invoke(audioRecord, shortBuffer, 0, FRAME_SIZE);
                if (n < 0) {
                    // ERROR_INVALID_OPERATION / ERROR_BAD_VALUE etc.
                    SimpleVoiceChatAECClient.LOGGER.debug("AudioRecord.read(short[]) returned {}", n);
                    return new short[FRAME_SIZE];
                }
                if (n < FRAME_SIZE) {
                    // Zero-pad remainder
                    for (int i = n; i < FRAME_SIZE; i++) {
                        shortBuffer[i] = 0;
                    }
                }
                short[] out = new short[FRAME_SIZE];
                System.arraycopy(shortBuffer, 0, out, 0, FRAME_SIZE);
                return out;
            }

            int bytes = (Integer) arReadBytes.invoke(audioRecord, readBuffer, 0, readBuffer.length);
            if (bytes < 0) {
                SimpleVoiceChatAECClient.LOGGER.debug("AudioRecord.read(byte[]) returned {}", bytes);
                return new short[FRAME_SIZE];
            }
            ByteBuffer bb = ByteBuffer.wrap(readBuffer, 0, Math.min(bytes, readBuffer.length))
                    .order(ByteOrder.LITTLE_ENDIAN);
            short[] out = new short[FRAME_SIZE];
            int samples = Math.min(bytes / 2, FRAME_SIZE);
            for (int i = 0; i < samples; i++) {
                out[i] = bb.getShort();
            }
            return out;
        } catch (Throwable t) {
            SimpleVoiceChatAECClient.LOGGER.error("AudioRecord read failed", t);
            return new short[FRAME_SIZE];
        }
    }
}
